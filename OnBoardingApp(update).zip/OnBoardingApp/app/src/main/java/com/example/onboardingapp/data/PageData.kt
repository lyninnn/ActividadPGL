package com.example.onboardingapp.data

data class PageData(
    val image : Int,
    val title : String,
    val desc: String
)