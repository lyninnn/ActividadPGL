package com.example.roomcronoapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CronosApplication: Application() {
}