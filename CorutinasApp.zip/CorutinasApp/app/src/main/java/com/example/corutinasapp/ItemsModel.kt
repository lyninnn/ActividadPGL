package com.example.corutinasapp

data class ItemsModel(
    val id : Int = 0,
    val name : String = ""
)
